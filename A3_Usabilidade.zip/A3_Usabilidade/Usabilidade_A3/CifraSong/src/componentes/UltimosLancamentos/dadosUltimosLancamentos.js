import mchariel from '../../imagens/mchariel.png.webp';
import bonezinha from '../../imagens/bonezinha.webp';
import vermelho from '../../imagens/vermelho.jpeg';

export const livros = [
  { nome: 'Mc Hariel', src: mchariel, id: 1 },
  { nome: 'Bonezinha', src: bonezinha, id: 2 },
  { nome: 'Vermelho', src: vermelho, id: 3 },
];
