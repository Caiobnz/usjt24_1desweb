// import {cadastrarUsuario, removerUsuario} from 'MATHEUSdataBase.js';

// setTimeout(() => {
//     cadastrarUsuario()
// }, 3000);
// removerUsuario()