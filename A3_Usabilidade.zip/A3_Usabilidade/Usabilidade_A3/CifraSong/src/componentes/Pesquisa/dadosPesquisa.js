import livro from '../../imagens/gloriagroove.png';

export const livros = [
  {
    nome: 'Gloria Groove - A queda',
    id: 1,
    src: livro,
    letra: `A Queda
Gloria Groove

Opções
Respeitável público
Um show tão maluco, essa noite, vai acontecer aqui
A gente vai armar um circo, um drama com perigo
E nessa corda bamba, quem vai caminhar sou eu

E venha ver os deslizes que vou cometer
E venha ver os amigos que eu vou perder
Não tô cobrando entrada, vem ver o show na faixa
Hoje tem open bar pra ver minha desgraça

Extra, extra! Não fique de fora dessa
Garanta seu ingresso pra me ver fazendo merda
Extra, extra! Logo logo o show começa
Melhor do que a subida só mesmo assistir a queda

Na, na
Na, na-na, na
Na, na-na, na
Na, na, na
Na, na-na, na-na, na

Na, na-na, na
Na, na-na, na
Na, na, na
Na, na-na, na-na, na`
  },
];
