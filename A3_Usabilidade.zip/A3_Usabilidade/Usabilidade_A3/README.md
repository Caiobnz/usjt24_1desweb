# README.md

![WhatsApp Image 2023-05-30 at 17 37 22](https://github.com/ThiagoCirelli7/Projeto-Ucs-2023.1/assets/69373402/7d5cdc4f-fb0b-4dc1-8581-53e224ce067d)

GRUPO:

- Matheus Aguiar Matos RA-822136827

- Caio de Jesus Santos RA-819148380

- João Flávio Miyasato Sanches RA-821146892 

- Lucas Nunes Garcez RA-822137433

- Thiago Sousa Mazili RA-822141922

- Thiago Vieiro Cirelli Lopes RA-822132178

- Vinicius Eduardo Ferreira RA - 81911506



VÍDEO DO PROJETO:

https://youtu.be/RzC___PxpGU



